package org.cap.dao;

import java.util.List;
import java.util.Map;

import org.cap.model.Account;

public interface IAccountDao {
public void createAccount(Account account);
public List<Account> getAllAccounts(int customerid);
public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId);
public List<Account> getToaccounts(Integer customerId);

public Account findAccount(int fromAccId); 
}
