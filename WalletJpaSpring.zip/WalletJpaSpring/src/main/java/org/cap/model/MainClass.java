package org.cap.model;


import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=factory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Customer customer=new Customer();
		customer.setCustomerPwd("gowthami13");
		customer.setFirstName("gowthami");
		customer.setLastName("chintamani");
		customer.setEmail("gowthami@gmail.com");
		customer.setLastLoginDate(new Date());
		customer.setMobile("1234567890");
		customer.setStatus("active");
		
		Account account=new Account();
		account.setAccountNo(1000001L);
		account.setAccountType("RD");
		account.setCustomer(customer);
		account.setOpeningDate(new Date());
		account.setOpeningBalance(10000);
		account.setStatus("active");
		account.setYears(5);
		
		Account account1=new Account();
		account1.setAccountNo(1000002L);
		account1.setAccountType("current");
		account1.setCustomer(customer);
		account1.setOpeningDate(new Date());
		account1.setOpeningBalance(10001);
		account1.setStatus("active");
		
		Account account2=new Account();
		account2.setAccountNo(1000003L);
		account2.setAccountType("savings");
		account2.setCustomer(customer);
		account2.setOpeningDate(new Date());
		account2.setOpeningBalance(10002);
		account2.setStatus("active");
		
		
		
		Customer customer1=new Customer();
		customer1.setCustomerPwd("max13");
		customer1.setFirstName("max");
		customer1.setLastName("Jen");
		customer1.setEmail("max@gmail.com");
		customer1.setLastLoginDate(new Date());
		customer1.setMobile("1234567899");
		customer1.setStatus("active");
		
		Account account3=new Account();
		account3.setAccountNo(1000004L);
		account3.setAccountType("savings");
		account3.setCustomer(customer1);
		account3.setOpeningDate(new Date());
		account3.setOpeningBalance(10003);
		account3.setStatus("active");
		
		Customer customer2=new Customer();
		customer2.setCustomerPwd("patrik13");
		customer2.setFirstName("patrik");
		customer2.setLastName("Jen");
		customer2.setLastLoginDate(new Date());
		customer2.setMobile("1234567888");
		customer2.setStatus("active");
		customer2.setEmail("patrik@gmail.com");
		

		Account account4=new Account();
		account4.setAccountNo(1000005L);
		account4.setAccountType("current");
		account4.setCustomer(customer2);
		account4.setOpeningDate(new Date());
		account4.setOpeningBalance(10005);
		account4.setStatus("active");
		
		
		
		
		
		entityManager.persist(customer);
		entityManager.persist(customer1);
		entityManager.persist(customer2);
		entityManager.persist(account);
		entityManager.persist(account1);
		entityManager.persist(account2);
		entityManager.persist(account3);
		entityManager.persist(account4);
		transaction.commit();




	}

}
