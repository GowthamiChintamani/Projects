package org.cap.service;

import java.util.Date;
import java.util.List;

import org.cap.dao.ITransactionDao;
import org.cap.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("transactionService")
public class TransactionService implements ITransactionservice {
	@Autowired
	private ITransactionDao transDao;
	@Override
	public void createAccount(Transaction transaction) {
		transDao.createAccount(transaction);
	}

	@Override
	public List<Transaction> getTransactions(Integer custId) {
		return transDao.getTransactions(custId);
	}

	@Override
	public void createTransaction(Transaction transaction) {
		transDao.createAccount(transaction);
		
	}

	@Override
	public void fundTransfer(Transaction transaction1) {
		transDao.fundTransfer(transaction1);
	}

	@Override
	public List<Transaction> getDatedTransactions(Integer customerId, Date d1, Date d2) {
		// TODO Auto-generated method stub
		return transDao.getDatedTransactions(customerId,d1,d2) ;
	}

}
