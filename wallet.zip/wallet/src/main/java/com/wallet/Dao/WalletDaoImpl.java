package com.wallet.Dao;


import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Optional;

import com.wallet.Db.WalletDB;
import com.wallet.bean.Transfer;
import com.wallet.bean.Wallet;
import com.wallet.exception.WalletException;


public class WalletDaoImpl implements WalletDao{
	
	
	static HashMap<Long,Wallet> CustomerMap=WalletDB.getCustomerMap();
	
	static HashMap<Integer,Transfer> TransferMap=WalletDB.getTransferMap();

	int transid=0;
	

	@Override
	public long createaccount(Wallet w) throws WalletException {
		try {
			if(CustomerMap.size()==0) {
				w.setAccountNo(123456789001L);
			}
			else {
				Optional<Long> id=CustomerMap.keySet().stream().max(new Comparator<Long>()
						{
					@Override
					public int compare(Long x,Long y)
							{
						return x>y?1:x<y?-1:0;
							}
						});
				long reqid=id.get()+1;
				w.setAccountNo(reqid);
			}
						
			CustomerMap.put(w.getAccountNo(),w);
			return w.getAccountNo();
		}catch(Exception ex)
		{
			throw new  WalletException (ex.getMessage());
		}

	}

	@Override
	public boolean validate(long accountno, String pin) throws WalletException {
		// TODO Auto-generated method stub
		Wallet t=CustomerMap.get(accountno);
		try {
			if(t==null)
				throw  new WalletException(" Enter Correct account number");
			if(t.getPin().equalsIgnoreCase(pin))
				return true;
			else
			{
				throw  new WalletException(" Enter Correct pin");
			}
		}catch(Exception ex)
		{
			throw new  WalletException (ex.getMessage());
		}
		
	}
	
	

	@Override
	public double showbalance(long accountno) throws WalletException {
		try
		{
			Wallet t=CustomerMap.get(accountno);
		return t.getBalance();
		
}catch(Exception ex)
		
		{
	throw new  WalletException (ex.getMessage());
}
	}

	@Override
	public double deposit(long accountno, double amount) throws WalletException {
		try{
			Wallet w=CustomerMap.get(accountno);
		w.setBalance(w.getBalance()+amount);
		transid++;
		TransferMap.put(transid, new Transfer(accountno,"deposit",LocalDate.now(),amount));
		return w.getBalance();
	}catch(Exception ex)
		{
		throw new  WalletException (ex.getMessage());
	}
	}
	@Override
	public double withdraw(long accountno, double amount) throws WalletException {
		try
		{
			Wallet w=CustomerMap.get(accountno);
			if(w.getBalance()>amount) {
				w.setBalance(w.getBalance()-amount);
				transid++;
				TransferMap.put(transid, new Transfer(accountno,"withdraw",LocalDate.now(),amount));
				return w.getBalance() ;
			}
			else
			{
				throw new  WalletException (" You Cannot Withdraw From Your Account Due To Low Balance");
			}
					
		}catch(Exception ex)
		{
		throw new  WalletException (ex.getMessage());
	}
		
	}

	@Override
	public double fundtransfer(long accountno1, long accountno2, double amount) throws WalletException {
		try {
			Wallet W1=CustomerMap.get(accountno1);
			Wallet W2=CustomerMap.get(accountno2);
			if(W1==null)
				throw new WalletException(" Enter a valid account number for the fund to be transfer");
			if(W2==null)
				throw new WalletException(" Enter your valid account number");
			if(W1==W2)
				throw new WalletException(" you cannot transfer to your own account");
			else {
				double money=W2.getBalance();
				if(money<amount)
				{
					throw new WalletException(" there is no sufficient balance in your account");
				}
				else if(money<=0)
				{
					throw new WalletException(" money to be transferred must be greater than 0");
				}
				else 
				{
					double newmoney=money-amount;
					W2.setBalance(newmoney);
					transid++;
					TransferMap.put(transid, new Transfer(accountno2,"fundtransfer",LocalDate.now(),amount));
					double money2=W1.getBalance();
					double newmoney2=money2+amount;
					W1.setBalance(newmoney2);
					
					return W2.getBalance();
					
					
				}
			}
			
			
		}catch(Exception ex)
		{
		throw new  WalletException (ex.getMessage());
		
	}

}

	@Override
	public boolean printtransaction(long accountno) throws WalletException {
		try {
			for(int k=1;k<=TransferMap.size();k++) {
				Transfer tran=TransferMap.get(k);
						if(tran.getAccountno()==accountno)
						{
							System.out.println(tran);;
						}
			}return false;
		}catch(Exception ex)
		{
			throw new  WalletException (ex.getMessage());
			
		}
		
	}
}
	
