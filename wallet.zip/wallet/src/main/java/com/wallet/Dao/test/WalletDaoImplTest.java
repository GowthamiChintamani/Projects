package com.wallet.Dao.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.wallet.Dao.WalletDao;
import com.wallet.Dao.WalletDaoImpl;
import com.wallet.Db.WalletDB;
import com.wallet.bean.Wallet;
import com.wallet.exception.WalletException;

public class WalletDaoImplTest {
	Wallet w = new Wallet();
WalletDao wdao=new WalletDaoImpl();
WalletDB Wdb=new WalletDB();
	@Test
	public void testCreateaccount() {
        assertEquals(7,Wdb.getCustomerMap().size());
        w.setAccountNo(123456789008l);
        w.setAccountType("Savings");
        w.setPhoneNo("1234590890");
        w.setAddress("Hyderabad");
        w.setAdhaarNo("123456789976");
        w.setEmail("gowthami@mail.com");
        w.setBalance(10000);
        w.setAge("18");
        w.setPin("6609");
        
        
        try {
              wdao.createaccount(w);
               
            assertEquals(8,Wdb.getCustomerMap().size());
        } catch (WalletException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
        }

	}

	@Test
	public void testValidate() {
		/*fail("Not yet implemented");*/
		try {
		assertEquals(true,wdao.validate(123456789007L,"7777"));
	}catch (WalletException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
 }
	}

	@Test
	public void testShowbalance() {
		
        try {
         assertEquals(Double.toString(012),Double.toString(wdao.showbalance(123456789004L)));
           
      
     } catch (WalletException e) {
            // TODO Auto-generated catch block
    	 e.printStackTrace();
     }

	}

	@Test
	public void testDeposit() {
		try {
            assertEquals(Double.toString(920),Double.toString(wdao.deposit(123456789007L,8)));
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }

	}

	@Test
	public void testWithdraw() {
		try {
            assertEquals(Double.toString(90),Double.toString(wdao.withdraw(123456789006L,8)));
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }
	}

	@Test
	public void testFundtransfer() {
        try {
        	  assertEquals(Double.toString(300),Double.toString(wdao.fundtransfer(123456789001L,123456789002L ,156)));
            
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }

	}

	@Test
	public void testPrinttransaction() {
	       try {
	              boolean b = wdao.printtransaction(123456789003l);
	              assertEquals(false,b);
	       } catch (WalletException e) {
	              // TODO Auto-generated catch block
	              e.printStackTrace();
	       }

	}

}
