package com.wallet.Dao.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.wallet.Dao.WalletDao;
import com.wallet.Dao.WalletDaoImpl;

import com.wallet.bean.Wallet;
import com.wallet.exception.WalletException;

public class WalletDaoImplTest {
	Wallet w = new Wallet();
WalletDao wdao=new WalletDaoImpl();
	@Test
	public void testCreateaccount() {
        
        w.setAccountNo(123456789005l);
        w.setAccountType("Savings");
        w.setPhoneNo("1234567890");
        w.setAddress("Hyd");
        w.setAdhaarNo("123456789076");
        w.setEmail("gowthami@mail.com");
        w.setBalance(10000);
        w.setAge("18");
        w.setPin("0000");
        
        
        try {
               long accountno=wdao.createaccount(w);
               
            assertEquals(accountno,123456789005l);
        } catch (WalletException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
        }

	}

	@Test
	public void testValidate() {
		/*fail("Not yet implemented");*/
		try {
		assertEquals(true,wdao.validate(123456789812l,"0000"));
	}catch (WalletException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
 }
	}

	@Test
	public void testShowbalance() {
		/*fail("Not yet implemented");*/
        try {
          double w= wdao.showbalance(123456789812l);
           
        
            assertNull(w);
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            System.out.println(e.getMessage());
     }

	}

	@Test
	public void testDeposit() {
		try {
            assertEquals(true, wdao.deposit(123456789812l, 10000));
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }

	}

	@Test
	public void testWithdraw() {
		try {
            assertEquals(true, wdao.deposit(123456789812l, 10000));
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }
	}

	@Test
	public void testFundtransfer() {
        try {
            assertEquals(true, wdao.fundtransfer(123456789812l,123456789002l, 10000));
            
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }

	}

	@Test
	public void testPrinttransaction() {
	       try {
	              boolean b = wdao.printtransaction(123456789812l);
	              assertFalse(b);
	       } catch (WalletException e) {
	              // TODO Auto-generated catch block
	              e.printStackTrace();
	       }

	}

}
