package com.wallet.Db;

import java.util.HashMap;

import com.wallet.bean.Transfer;
import com.wallet.bean.Wallet;

public class WalletDB {
	private static HashMap<Long,Wallet>
	CustomerMap=new HashMap<Long,Wallet>();
	private static HashMap<Integer,Transfer>
	TransferMap=new HashMap<Integer,Transfer>();
	static {
		CustomerMap.put(123456789001L,new Wallet("Gowthami",123456789001L,"current","1234567890","Hyd","123456789012","gowthami@gmail.com",123,"23","1111"));
		CustomerMap.put(123456789002L,new Wallet("Mark",123456789002L,"savings","1234567878","Bangalore","123456789125","mark@gmail.com",456,"78","2222"));
		CustomerMap.put(123456789003L,new Wallet("Patrick",123456789003L,"current","1234567800","Pune","123456789077","patrik@gmail.com",789,"66","3333"));
		CustomerMap.put(123456789004L,new Wallet("Jen",123456789004L,"salary","1234567899","Chennai","123456789456","jen@gmail.com",012,"18","4444"));
		CustomerMap.put(123456789005L,new Wallet("Cane",123456789005L,"salary","1234567844","Mumbai","123456789122","cane@gmail.com",112,"18","5555"));
		CustomerMap.put(123456789006L,new Wallet("Max",123456789006L,"salary","1234567811","Goa","123456789987","max@gmail.com",98,"18","6666"));
		CustomerMap.put(123456789007L,new Wallet("Bill",123456789007L,"salary","1234567833","Chennai","12345678457","bill@gmail.com",912,"18","7777"));
		
	}
	public static HashMap<Long, Wallet> getCustomerMap() {
		return CustomerMap;
	}
public static HashMap<Integer,Transfer> getTransferMap()
{
	return TransferMap;
}
}