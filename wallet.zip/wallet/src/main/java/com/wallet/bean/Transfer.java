package com.wallet.bean;

import java.time.LocalDate;



public class Transfer {
	private String transfertype;
	private LocalDate date;
	private double amount;
	
	private long accountno;
	
	

	public long getAccountno() {
		return accountno;
	}

	public void setAccountno(long accountno) {
		this.accountno = accountno;
	}

	public String getTransfertype() {
		return transfertype;
	}
	
	public void setTransfertype(String transfertype) {
		this.transfertype = transfertype;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public Transfer( long accountno,String transfertype, LocalDate date, double amount) {
		super();
		this.transfertype = transfertype;
		this.date = date;
		this.amount = amount;

		this.accountno = accountno;
	}

	public Transfer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Account Number= " +accountno+ "Transfer type=" + transfertype + ", Date=" + date + ", Amount= " + amount;
	}

}
