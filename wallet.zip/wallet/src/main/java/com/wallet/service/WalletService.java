package com.wallet.service;

import com.wallet.bean.Transfer;
import com.wallet.bean.Wallet;
import com.wallet.exception.WalletException;

public interface WalletService 
{
	boolean validateWallet(Wallet W) throws WalletException;
	long createaccount(Wallet W) throws WalletException;
	boolean validate(long accountno,String pin) throws WalletException;
	double showbalance(long accountno) throws  WalletException;
	double deposit(long accountno,double amount) throws  WalletException;
	double withdraw(long accountno,double amount) throws  WalletException;
	double fundtransfer(long accountno1,long accountno2,double amount) throws  WalletException;
	boolean printtransaction(long accountno)  throws  WalletException;
	;
}
