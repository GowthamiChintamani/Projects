package com.wallet.service;
import com.wallet.Dao.WalletDao;
import com.wallet.Dao.WalletDaoImpl;
import com.wallet.bean.Transfer;
import com.wallet.bean.Wallet;
import com.wallet.exception.WalletException;
public class WalletServiceImpl implements WalletService {
	WalletDao Wdao=new WalletDaoImpl();

	@Override
	public boolean validateWallet(Wallet W) throws WalletException {
		if(validateName(W.getName())&&validateAccountType(W.getAccountType())&&validatePhoneNo(W.getPhoneNo())&&validateAddress(W.getAddress())&&validateAdharrNo(W.getAdhaarNo())&&validateEmail(W.getEmail())&&validateAge(W.getAge())&&validatePin(W.getPin())) {
			return true;
		}
		return false;
	}
	private boolean validatePin(String pin) throws WalletException {
		if(pin.isEmpty()|| pin==null) {
			throw new WalletException("pin is mandatory");
			
		}
		else {
			if(!pin.matches("\\d{4}")){
				throw new WalletException(" pin should contain only 4 digits");
				
			}
		}
		
		return true;
	}
	private boolean validateAge(String age) throws WalletException {
		if(age.isEmpty() ||age==null) {
			throw new WalletException("Age cannot be empty");
		}
		else {
			if(age.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletException("Enter Valid Age");
			}
			else {
				if(Integer.parseInt(age)<18||Integer.parseInt(age)>=100)
					throw new WalletException(" Age should be between 18 and 100");
					
			}
				
			}
		
		return true;
	}
	private boolean validateAccountType(String accountType)  throws WalletException{
		if(accountType.isEmpty() || accountType==null) {
			throw new WalletException("account type cannot be empty");
		}
		
			else if(!(accountType.equalsIgnoreCase("Savings")||accountType.equalsIgnoreCase("Current")||accountType.equalsIgnoreCase("salary")))
			{
				throw new WalletException(" Account type should be Savings,Current or Salary only");
			}
		
		
		return true;
		}

private boolean validateEmail(String email) throws WalletException {
		if(!email.matches("[A-Za-z0-9_]+@[a-z]+\\.com")) {
			throw new WalletException("please enter a valid email id");
		}
		return true;
	}

	private boolean validateAdharrNo(String adhaarNo) throws WalletException  {
		if(adhaarNo.isEmpty()|| adhaarNo==null) {
			throw new WalletException(" adhaar number is mandatory");
			
		}
		else {
			if(!adhaarNo.matches("\\d{12}")){
				throw new WalletException("adhaar number should contain only 12 digits");
				
			}
		}
		return true;
		
	}

	private boolean validateAddress(String address) throws WalletException {
		if(address.isEmpty() || address==null) {
			throw new WalletException("address cannot be empty");
		}
		else {
			if(!(address.matches("[A-Z][A-Za-z]{2,}"))) {
				throw new WalletException(" address should start with a capital letter followed by a min of 2 alphabets");
			}
		}
		
		return true;
		
	}

	private boolean validatePhoneNo(String phoneNo) throws WalletException {
		if(phoneNo.isEmpty()|| phoneNo==null) {
			throw new WalletException("phone number is mandatory");
			
		}
		else {
			if(!phoneNo.matches("\\d{10}")){
				throw new WalletException(" phone number should contain only 10 digits");
				
			}
		}
		return true;
	}	
	private boolean validateName(String name) throws WalletException {
		if(name.isEmpty() || name==null) {
			throw new WalletException("customer name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletException(" customer name should start with a capital letter followed by a min of 2 alphabets");
			}
		}
		
		return true;
	}

	@Override
	public long createaccount(Wallet W) throws WalletException {
		
		return Wdao.createaccount(W);
	}
	@Override
	public boolean validate(long accountno, String pin) throws WalletException {
		
		return Wdao.validate(accountno,pin);
	}
	@Override
	public double showbalance(long AccountNo) throws WalletException {

		return Wdao.showbalance(AccountNo);
	}
	@Override
	public double deposit(long accountno,double amount) throws WalletException{
		// TODO Auto-generated method stub
		return Wdao.deposit(accountno,amount);
		
	}
	@Override
	public double withdraw(long accountno, double amount) throws WalletException {
		// TODO Auto-generated method stub
		return Wdao.withdraw(accountno,amount);
	}
	@Override
	public double fundtransfer(long accountno1, long accountno2, double amount) throws WalletException {
		// TODO Auto-generated method stub
		return Wdao.fundtransfer(accountno1,accountno2,amount);
	}
	@Override
	public boolean printtransaction(long accountno) throws WalletException {
		
		return Wdao.printtransaction(accountno);
	}
	
}
