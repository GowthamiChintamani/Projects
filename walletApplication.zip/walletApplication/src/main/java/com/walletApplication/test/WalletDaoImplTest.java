package com.walletApplication.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.walletApplication.Dao.WalletDao;
import com.walletApplication.Dao.WalletDaoImpl;
import com.walletApplication.bean.Wallet;
import com.walletApplication.exception.WalletException;


public class WalletDaoImplTest {
	Wallet w = new Wallet();
WalletDao wdao=new WalletDaoImpl();

	@Test
	public void testCreateaccount() {
       
       
        w.setAccountType("Savings");
        w.setPhoneNo("1234590890");
        w.setAddress("Hyderabad");
        w.setAdhaarNo("123456789976");
        w.setEmail("gowthami@mail.com");
        w.setBalance(10000);
        w.setAge("18");
        w.setPin("6609");
        
        
        try {
              wdao.createaccount(w);
               
            
        } catch (WalletException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
        }

	}

	@Test
	public void testValidate() {
		/*fail("Not yet implemented");*/
		try {
		assertEquals(true,wdao.validate(1,"1234"));
	}catch (WalletException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
 }
	}

	@Test
	public void testShowbalance() {
		
        try {
         assertEquals(Double.toString(5060),Double.toString(wdao.showbalance(1)));
           
      
     } catch (WalletException e) {
            // TODO Auto-generated catch block
    	 e.printStackTrace();
     }

	}

	@Test
	public void testDeposit() {
		try {
            assertEquals(Double.toString(3640),Double.toString(wdao.deposit(2,1000)));
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }

	}

	@Test
	public void testWithdraw() {
		try {
            assertEquals(Double.toString(2640),Double.toString(wdao.withdraw(2,1000)));
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }
	}

	@Test
	public void testFundtransfer() {
        try {
        	  assertEquals(Double.toString(1640),Double.toString(wdao.fundtransfer(1,2 ,1000)));
        	  assertEquals(Double.toString(5060),Double.toString(wdao.fundtransfer(2,1 ,1000)));
     } catch (WalletException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
     }

	}

	@Test
	public void testPrinttransaction() {
	       try {
	              boolean b = wdao.printtransaction(1);
	              assertEquals(false,b);
	       } catch (WalletException e) {
	              // TODO Auto-generated catch block
	              e.printStackTrace();
	       }

	}

}

